$(document).on('click', function(event) {
   $(".image").animate({left: "+=80%"}, 1500);
});
